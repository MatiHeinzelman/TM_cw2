#include "main.h"

//#define	ASM_EXMPL

unsigned short int *const LCD_FB = (unsigned short int*) 0xD0000000;	// Adres framebuffer-a
unsigned short int *const LCD_BUF = (unsigned short int*) 0xD0100000; 	// Adres graficznego bufora pomocniczego

//Stwórz strukturę kwadrat w pamięci o adresie wyrównanym do 4-ech bajtów
kwadrat_t __attribute__((aligned(4))) kwadrat={.x=120,.y=160,.dx=1,.dy=1,.size=30}  ;


int main(void) {

	System_Init();						// Wywołanie procedury inicjalizującej system wbudowany

	while (1) {							// Nieskończona pętla główna
		handleGPIO();					// Wywołanie procedury obsługi portów GPIO
		Clear_And_Reload_Screen();		// Wywołanie procedury kopiowania bufora LCD_BUF do framebuffera
		fillMemory((void*) LCD_BUF, 320 * 240, 0x8040);	// Wywołanie procedury zaimplementowanej w asemblerze, wypełniającej zadany obszar pamięci wskazanym półsłowem
		printText();					// Wywołanie procedury generującej reprezentację łańcucha tekstowego w buforze LCD_BUF
    	drawElements();					//Wywołanie procedury generującej kolorowy kwadrat i odcinki w czterech narożnikach bufora LCD_BUF
	}
}

//Procedura obsługi przerwania od SysTick-a
void SysTick_Handler(void) {
	HAL_IncTick();	// Wewnętrzny licznik biblioteki HAL inkrementowany co 1 ms
}

//Procedura inicjalizująca system wbudowany
void System_Init() {
	HAL_Init();				// Inicjalizacja biblioteki HAL
	SystemClock_Config();	// Inicjalizacja układów zegarowych
	BSP_SDRAM_Init();		// Inicjalizacja zewnętrznej pamięci SDRAM
	BSP_LCD_Init();			// Inicjalizacja wyświetlacza LCD

	RCC->AHB1ENR |= RCC_AHB1ENR_GPIOGEN;		// Załączenie sygnału zegarowego dla portu G (obsługa diody LED LD4)
	GPIOG->MODER |= GPIO_Mode_OUT << (14 * 2); 	// Ustawienie 14-go pinu portu G do pracy wyjściowej (obsługa diody LED LD4)
	RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN;		// Załączenie sygnału zegarowego dla portu A (obsługa przycisku B1)
}

//Procedura obsługi portów GPIO
void handleGPIO() {
	if (!(GPIOA->IDR & 1))					// Sprawdzenie stanu przycisku B1
		GPIOG->BSRR = GPIO_Pin_14; 			// Jeśli niewciśnięty, to wysteruj diodę LED LD4
	else
		GPIOG->BSRR = GPIO_Pin_14 << 16; 	// Jeśli wciśnięty, to zgaś diodę LED LD4
}

// Procedura kopiowania bufora LCD_BUF do framebuffer-a
void Clear_And_Reload_Screen() {

#ifdef ASM_EXMPL
	kopiuj_blok_pamieci(LCD_BUF, LCD_FB, 320 * 240 / 2);
	kasuj_blok_pamieci(LCD_BUF, 320 * 240 / 2);
#else
 for (int off = 0; off < 320*240; off++) {
	 LCD_FB[off]=LCD_BUF[off];
	 LCD_BUF[off]=0;
    }
#endif
}

// Procedura generująca reprezentację łańcucha tekstowego w buforze LCD_BUF
void printText() {
	BSP_LCD_DisplayStringAt(10, 10, (uint8_t*) "T e e M y", LEFT_MODE);
	BSP_LCD_DisplayRot90StringAt(0, 10, (uint8_t*) "Demo Mode", CENTER_MODE);
}

// Procedura generującej kolorowy kwadrat i odcinki w czterech narożnikach bufora LCD_BUF
void drawElements() {
//Rysuj cztery odcinki koloru białego, po 20 pikseli każdy
#define L_LINE 20
#define L_OFFSET (L_LINE-1)
	for (unsigned int idx = 0; idx < L_LINE; idx++) {
		LCD_BUF[idx 					  +	0] = 0xffff;
		LCD_BUF[LCD_LAST_X 				  +	(idx * LCD_WIDTH) ] = 0xffff;
		LCD_BUF[0 						  +	((LCD_LAST_Y - L_OFFSET + idx) * LCD_WIDTH)] = 0xffff;
		LCD_BUF[(LCD_LAST_X-L_OFFSET+idx) + (LCD_LAST_Y * LCD_WIDTH ) ] = 0xffff;
	}

//Zmień współrzędne położenia kwadratu z wykorzystaniem ...
#ifdef	ASM_EXMPL
	move_square_asm();	// ... procedury zaimplementowanej w asemblerze
#else
	move_square_C();	// ... procedury zaimplementowanej w języku C
#endif
//Rysuj 32 wiersze kwadratu...
	for (unsigned int yy = 0; yy < kwadrat.size ; yy++) {
// ... wyznaczając adres pierwszego piksela w każdym wierszu ...
		unsigned short int *pixel = (unsigned short int*) (LCD_BUF + kwadrat.x
				+ (kwadrat.y + yy) * LCD_WIDTH);
// ... i iterującej przez wszystkie kolumny (piksele w wierszu) ...
		for (unsigned int xx = 0; xx < kwadrat.size; xx++) {

//Dla każdego piksela wyznacz jego składowe koloru ...
			unsigned int R = MAX_R * kwadrat.x / LCD_WIDTH;
			unsigned int G = MAX_G * (xx + yy) / (2*kwadrat.size);
			unsigned int B = MAX_B * kwadrat.y / LCD_HEIGHT;

// ... i umieść w buforze graficznym
#ifdef	ASM_EXMPL
			*pixel++ = RGB16Pack(B, G, R);
#else
			*pixel++ =	((R & 0x1f) << 11)	| ((G & 0x3f) << 5 ) | (B & 0x1f) ;
#endif
		}
	}
}

// Procedura zmieniająca położenie kwadratu na LCD
void move_square_C() {

//Kontrola zakresu zmian współrzędnych x,y
	if (kwadrat.x <  ABS(kwadrat.dx) || kwadrat.x > LCD_WIDTH - 1 - kwadrat.size - ABS(kwadrat.dx))
		kwadrat.dx = -kwadrat.dx;
	if (kwadrat.y < ABS(kwadrat.dy) || kwadrat.y > LCD_HEIGHT - 1 - kwadrat.size - ABS(kwadrat.dy))
		kwadrat.dy = -kwadrat.dy;

//Aktualizacja położenia o wektor predkości dx,dy
		kwadrat.x = (unsigned int) ((int) kwadrat.x+ kwadrat.dx);
		kwadrat.y = (unsigned int) ((int) kwadrat.y+ kwadrat.dy);
}

